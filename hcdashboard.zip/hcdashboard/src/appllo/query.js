import gql from "graphql-tag";

export const QUERY_TECHNICIAN = gql`
  query {
    users(where: { role: { name: "Technician" } }) {
      id
      firstname
      lastname
      email
      identification_number
      phone_number
      status
      count_view
      count_click
    }
  }
`;
export const QUERY_TECHNICIAN_BY_ID = gql`
  query ($id: ID!) {
    user(id: $id) {
      id
      email
      username
      firstname
      lastname
      role {
        id
        name
      }
      ratings {
        score
        image {
          id
          url
          provider
        }
      }
      company_name
      company_phone
      identification_number
      phone_number
      gender
      image_show {
        id
        url
        provider
      }
      image_cover {
        id
        url
        provider
      }
      company_logo {
        id
        url
        provider
      }
      image_avatar {
        id
        url
        provider
      }
      description
      payment_types {
        name
      }
      bank_name
      bank_account
      bank_name_account
      bank_type
      bank_branch
      tax_number
      company_address
      company_province
      work_time
      off_time
      work_day
      private_address
      address
      district
      role {
        name
      }
      sub_district
      province
      zipcode
      google_iframe
      icon {
        id
        url
        provider
      }
      count_view
      count_click
      sub_types {
        id
        name
      }
    }
  }
`;

export const QUERY_FINANCE_CUSTOMER = gql`
  query {
    finances(sort: "status:asc") {
      id
      status
      token
      appointment_number
      customer_name
      technician_name
      customer_email
      customer_pay_date
      customer_amount_cash
      customer_approver_name
      customer_status_approve
      customer_money_transfer_slip {
        provider
        url
      }
    }
  }
`;

export const QUERY_FINANCE_TECHNICIAN = gql`
  query {
    finances(where: { status: ["d", "e"] }, sort: "status:asc") {
      id
      status
      appointment_number
      customer_amount_cash
      technician_bank_name
      technician_name
      technician_bank_number
      technician_email
      technician_pay_date
      technician_amount_cash
      technician_approver_name
      technician_status_payment
      technician_status_approve
      technician_money_transfer_slip {
        provider
        url
      }
    }
  }
`;

export const QUERY_USER = gql`
  query {
    users(where: { role: { name: "User" } }) {
      id
      firstname
      lastname
      email
      identification_number
      phone_number
    }
  }
`;

export const QUERY_REFERRAL = gql`
  query ($where: JSON) {
    finances(where: $where, sort: "status:asc") {
      id
      status
      customer_name
      appointment_number
      customer_phone_number
      customer_amount_cash
      referral_amount_cash
      referral
      referral_pay_date
      referral_money_transfer_slip {
        provider
        url
      }
    }
  }
`;

export const QUERY_USER_BY_ID = gql`
  query ($id: ID!) {
    user(id: $id) {
      id
      firstname
      lastname
      email
      phone_number
      bank_account
      bank_name_account
      bank_name
    }
  }
`;

export const QUERY_REGISTER = gql`
  query {
    registers(sort: "status:desc") {
      id
      username
      password
      email
      status
      name
      citizen_number
      phone
      address_detail
      tag
      work_days
      work_time
      off_time
      description
      image_cover {
        provider
        url
      }
      profile_image {
        provider
        url
      }
      province
      id_card {
        provider
        url
      }
    }
  }
`;

export const QUERY_STATUS = gql`
  query {
    finances {
      id
      status
      referral
    }
  }
`;

export const QUERY_REGISTER_STATUS = gql`
  query {
    registers {
      status
    }
  }
`;

export const QUERY_SEARCH_USER = gql`
  query {
    users(where: { role: { name: "Technician" } }) {
      id
      image_avatar {
        url
        provider
      }
      firstname
      lastname
      province
      role {
        name
      }
      sub_types {
        name
      }
    }
  }
`;

export const QUERY_SEARCH_FINANCE = gql`
  query {
    quatations {
      id

      number
    }
  }
`;

export const QUERY_SEARCH_FINANCE_BY_ID = gql`
  query ($id: ID!) {
    quatation(id: $id) {
      id
      createdAt
      all_price
      company_name
      technician_name
      technician_address
      technician_phone_number
      customer_name
      customer_email
      customer_address
      customer_phone_number
      duration
      Order {
        id
        index
        detail
        count
        price_per_unit
        name
        unit
      }
      note
      number
      discount
      tax
      logo {
        id
        provider
        url
      }
    }
  }
`;
export const QUERY_TECHNICIAN_COUNT = gql`
  query {
    users(where: { role: { name: "Technician" }, status: "Public" }) {
      count_view
      count_click
    }
  }
`;

export const QUERY_COUNT_QUOTATION = gql`
  query {
    quatations {
      id
    }
  }
`;

export const QUERY_COUNT_APPOINTMENT = gql`
  query {
    appointments {
      id
    }
  }
`;

export const QUERY_COUNT_FINISH = gql`
  query {
    finances(where: { status: ["d", "e", "f"] }) {
      id
    }
  }
`;

export const QUERY_COMMENT_PRODUCT = gql`
  query QueryCommentProduct($id: String!) {
    ratings(where: { user_id: $id }, sort: "createdAt:desc") {
      id
      comment
      score
      user_id
      image {
        id
        url
        provider
      }
      users_permissions_user {
        id
        firstname
        lastname
        image_social
        image_avatar {
          id
          url
          provider
        }
      }
    }
  }
`;

export const QUERY_CARD_TECHNICIANS_RECOMMEND = gql`
  query {
    recommends {
      id
      users_permissions_user {
        id
        firstname
        lastname
        image_avatar {
          id
          url
          provider
        }
        role {
          name
        }

        image_cover {
          id
          url
          provider
        }
        province
        description
        district
        sub_district
        province
        count_view
        sub_types {
          id
          name
        }
      }
    }
  }
`;
