import gql from "graphql-tag";
export const UPDATE_FINANCE = gql`
  mutation updateFinance($input: updateFinanceInput) {
    updateFinance(input: $input) {
      finance {
        id
      }
    }
  }
`;
export const UPDATE_STATUS = gql`
  mutation updateRegister($input: updateRegisterInput) {
    updateRegister(input: $input) {
      register {
        id
      }
    }
  }
`;

export const CREATE_TECNICIAN = gql`
  mutation createUser($input: createUserInput) {
    createUser(input: $input) {
      user {
        id
      }
    }
  }
`;

export const CREATE_RECOMMEND = gql`
  mutation createRecommend($input: createRecommendInput) {
    createRecommend(input: $input) {
      recommend {
        id
      }
    }
  }
`;

export const DELETE_RECOMEMD = gql`
  mutation deleteRecommend($input: deleteRecommendInput) {
    deleteRecommend(input: $input) {
      recommend {
        id
      }
    }
  }
`;
