import React, { Component, useState, useContext } from "react";
import { useHistory, Redirect } from "react-router-dom";
import { AppContext } from "../context/AppContext";
import axios from "axios";
import Swal from "sweetalert2";

const User = () => {
  // const router = useHistory();
  const { setUser } = useContext(AppContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const accessToken = localStorage.getItem("jwt");

  const onChangeEmail = (e) => {
    setEmail(e.target.value);
  };
  const onChangePassword = (p) => {
    setPassword(p.target.value);
  };

  const onClickSubmitSignIn = async () => {
    setLoading(true);
    try {
      const { data } = await axios({
        method: "POST",
        url: "https://admin.celestialproperty-api.xyz/admin/login",
        headers: {
          Accept: "application/json",
        },
        data: { email: email, password: password },
      });
      const token = data?.data?.token;
      localStorage.setItem("jwt", token);
      localStorage.setItem(
        "name",
        `${data?.data?.user?.firstname} ${data?.data?.user?.lastname}`
      );
      await setUser({
        token: localStorage.getItem("jwt"),
        name: `${data?.data?.user?.firstname} ${data?.data?.user?.lastname}`,
      });

      setLoading(false);
    } catch (error) {
      setLoading(false);
      await Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "อีเมลหรือรหัสผ่านไม่ถูกต้อง โปรดลองใหม่อีกครั้ง",
      });
      setPassword("");
    }
  };
  if (loading) return <div>Loading....</div>;
  if (accessToken) return <Redirect to="/" />;

  return (
    <div className="font-kanit bg-gray-100">
      <div className="sm:bg-user2 bg-user1  bg-no-repeat sm:w-full sm:max-w-3xl sm:mx-auto absolute top-0 right-0 left-0">
        <div className=" mx-auto  ">
          <div className="p-5">
            <div className="relative"></div>

            <div className=" flex flex-col items-center sm:ml-4">
              <div>
                <img
                  className="mt-14 sm:mt-36 h-36 w-auto "
                  src="./logo/logo.PNG"
                ></img>
              </div>

              <form>
                <div className="sm:ml-4">E-mail</div>
                <div>
                  <input
                    value={email}
                    onChange={onChangeEmail}
                    className="p-4 my-2 bg-gray-200 h-12 w-80 rounded-2xl outline-none "
                    type="text"
                    placeholder=""
                    name="email"
                  />
                </div>
                <div className="sm:ml-4">Password</div>
                <div>
                  <input
                    value={password}
                    onChange={onChangePassword}
                    className="p-4 my-2 bg-gray-200 h-12 w-80 rounded-2xl outline-none "
                    type="password"
                    id="pass"
                    placeholder=""
                    name="password"
                  />
                </div>
                <div className="">
                  <button
                    onClick={onClickSubmitSignIn}
                    className="bg-yellow-400 text-white outline-none  w-full mt-6 cursor-pointer hover:bg-green2 h-12   rounded-2xl "
                  >
                    Sign In
                  </button>
                </div>
              </form>
              <div className="py-16 sm:py-10  "></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default User;
