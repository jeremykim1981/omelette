import ContainerContent from "../Container/ContainerContent";
import ApolloClient from "../../appllo/apolloClient";
import {
  QUERY_CARD_TECHNICIANS_RECOMMEND,
  QUERY_SEARCH_USER,
} from "../../appllo/query";
import Skeleton from "react-loading-skeleton";
import React, { useEffect, useState } from "react";
import { getPathUrl } from "../../utils/getPathUrl";
import ProductCard from "./Card";
import Select from "react-select";
import { CREATE_RECOMMEND } from "../../appllo/mutation";

const yello200 = "#FDE68A";
const gray800 = "#374151";

const SplitSkeleton = () => {
  return (
    <div className="relative bg-white  cursor-pointer font-Kanit  lg:mx-0   rounded rounded-t-lg overflow-hidden shadow md:max-w-xs my-3 ">
      <div className="w-full h-48 object-cover object-bottom">
        <Skeleton width={"100%"} height={"100%"} />
      </div>
      <div className="flex justify-center -mt-8  object-cover rounded-full border-solid border-white border-2  object-top">
        <Skeleton circle={true} height={85} width={85} />
      </div>
      <div className="text-center px-3 pb-6 pt-4 h-40">
        <Skeleton width={"100%"} height={25} />
        <Skeleton width={"100%"} height={"65%"} />
        <Skeleton width={"100%"} height={25} />
      </div>
      <div className="flex justify-center items-center  ">
        <Skeleton height={25} width={"100%"} />
      </div>
    </div>
  );
};

const LoadingSkeleton = () => {
  return (
    <div className="mx-1 md:mx-4 xl:mx-12  p-2 grid grid-cols-1 gap-4  md:grid-cols-2 xl:grid-cols-4 lg:justify-between">
      <SplitSkeleton />
      <SplitSkeleton />
      <SplitSkeleton />
      <SplitSkeleton />
    </div>
  );
};

const ImageAndName_technician = ({
  name,
  image,
  province,
  sub_types,
  role,
}) => {
  return (
    <div className="flex">
      <div className="flex">
        <div className="w-16 h-16 mr-4 p-1">
          <img
            className="w-full h-full object-cover rounded-md"
            src={image?.url ? getPathUrl(image?.url) : "/logo/logo.PNG"}
          />
        </div>
        <div className="grid grid-cols-1">
          <div className="font-semibold text-sm my-auto">{name}</div>
          <div className="font-semibold text-sm my-auto">
            {sub_types?.slice(0, 5)?.map((row) => {
              return row.name + " ";
            })}
          </div>
          <div className="font-semibold text-sm my-auto">{province}</div>
        </div>
      </div>
      {/* <div className="ml-auto my-auto">{role}</div> */}
    </div>
  );
};

const RecommendMain = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [choose, setChoose] = useState("");
  const [getOptions, setGetOptions] = useState("");

  useEffect(async () => {
    await LoadData();
  }, []);

  const LoadData = async () => {
    try {
      setLoading(true);

      const { data } = await client.query({
        query: QUERY_CARD_TECHNICIANS_RECOMMEND,
      });

      const { data: technician } = await client.query({
        query: QUERY_SEARCH_USER,
      });

      const technicians = technician?.users?.map((row) => {
        return {
          value: row?.id,
          label: row?.firstname + " " + row?.lastname,
          key: "User",
          renderLabel: (
            <ImageAndName_technician
              name={row?.firstname + " " + row?.lastname}
              image={row?.image_avatar}
              province={row?.province}
              sub_types={row?.sub_types}
              role={row?.role?.name}
            />
          ),
        };
      });

      setData(data?.recommends);

      setGetOptions({
        technicians,
      });
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const options = [
    {
      label: "ช่าง",
      options: getOptions?.technicians,
    },
  ];

  const customStyles = {
    control: (base) => ({
      ...base,
      border: 0,
      boxShadow: "none",
      backgroundColor: "#F3F4F6",
      minHeight: "100px",
      height: "100px",
    }),
    menu: (provided) => ({
      ...provided,
      border: "none",
      boxShadow: "none",
    }),
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isFocused && yello200,
      color: state.isFocused && gray800,
    }),
    valueContainer: (provided, state) => ({
      ...provided,
      height: "100px",
      padding: "0 6px",
    }),
  };

  const onClickAdd = async () => {
    try {
      await client.mutate({
        mutation: CREATE_RECOMMEND,
        variables: {
          input: {
            data: {
              users_permissions_user: choose,
            },
          },
        },
      });
    } catch (error) {
    } finally {
      await LoadData();
    }
  };

  return (
    <ContainerContent>
      <div className="mx-8 border border-graytext rounded-xl bg-white py-10">
        <div className="mx-4 text-xl  font-medium">ช่างที่แนะนำ</div>
        <div className="px-4 md:px-8 lg:px-16 pt-10 mx-auto">
          <div className="my-4 mx-auto h-full">
            <Select
              placeholder="เลือกช่างที่ต้องการเพิ่ม"
              options={options}
              isLoading={loading}
              getOptionLabel={(option) => option.renderLabel}
              getOptionValue={(option) => option.label}
              onChange={(event) => {
                setChoose(event?.value);
              }}
              styles={customStyles}
            />
          </div>
          <div
            onClick={() => onClickAdd()}
            className=" my-4 bg-yellow-400 text-white px-6 py-2 rounded-lg text-center"
          >
            เพิ่ม
          </div>
        </div>
        <div className="px-4 md:px-8 lg:px-16 pt-10">
          {loading ? (
            <LoadingSkeleton />
          ) : (
            <div className="grid grid-cols-2">
              {data?.slice(0, 8)?.map((row, index) => {
                const card = row?.users_permissions_user;
                const url = getPathUrl(card?.image_avatar?.url);
                const imgbgUrl = getPathUrl(card?.image_cover?.url);
                const sub_types = card?.sub_types?.map((type) => {
                  return type?.name + " ";
                });
                const name = card.firstname + " " + card.lastname;
                return (
                  <ProductCard
                    key={index}
                    imgbg={imgbgUrl}
                    img={url}
                    name={name}
                    desc={card.description}
                    text={sub_types}
                    productId={card.id}
                    count_view={card.count_view}
                    province={card?.province}
                    card_id={row?.id}
                    LoadData={LoadData}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>
    </ContainerContent>
  );
};
export default RecommendMain;
