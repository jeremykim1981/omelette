import React, { useEffect, useState } from "react";
import ApolloClient from "../../appllo/apolloClient";
import { DELETE_RECOMEMD } from "../../appllo/mutation";
import { QUERY_COMMENT_PRODUCT } from "../../appllo/query";
import { calculaterStar } from "../../functions/functions";
import DeleteModal from "../Modals/DeleteModal";

const Star = ({ fill = true }) => {
  return (
    <svg
      className="md:w-4 md:h-4 w-3 h-3"
      fill={fill ? "#FBC731" : "#fff"}
      stroke="#FBC731"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
      />
    </svg>
  );
};

const ProductCard = ({
  imgbg,
  img,
  name,
  desc,
  text,
  productId,
  count_view,
  province,
  card_id,
  LoadData,
}) => {
  const { client } = ApolloClient();
  const [ratings, setRatings] = useState("");
  const [open, setOpen] = useState(false);

  useEffect(async () => {
    await loadComment();
  }, []);

  const onClickDelete = async () => {
    return (
      await client.mutate({
        mutation: DELETE_RECOMEMD,
        variables: {
          input: {
            where: {
              id: card_id,
            },
          },
        },
      }),
      setOpen(false),
      LoadData()
    );
  };

  const loadComment = async () => {
    const { data } = await client.query({
      query: QUERY_COMMENT_PRODUCT,
      variables: {
        id: productId,
      },
    });
    setRatings(data?.ratings);
  };

  const amount_of_comment = ratings?.length;
  const avgRating = calculaterStar(ratings, amount_of_comment) || "ไม่มี";

  const CalStar = () => {
    return (
      <div className="flex justify-center items-center">
        <div className="  justify-center items-center flex gap-1 mr-2">
          <Star fill={avgRating >= 1} />
          <Star fill={avgRating >= 2} />
          <Star fill={avgRating >= 3} />
          <Star fill={avgRating >= 4} />
          <Star fill={avgRating >= 5} />
        </div>
        <div className=" text-textgray text-xs">{`${avgRating} (${ratings?.length} รีวิว)`}</div>
      </div>
    );
  };

  const Type = () => {
    return (
      <div className="flex justify-center items-center ">
        {text.length > 3
          ? text?.slice(0, 3)?.map((row) => {
              return (
                <div className=" flex items-center justify-center text-gray-700  font-normal  bg-gray-100 border   rounded-xl h-6 md:h-8 px-4 mr-2   text-xs">
                  {row}
                </div>
              );
            })
          : text?.map((row) => {
              return (
                <div className=" flex items-center justify-center text-gray-700  font-normal  bg-gray-100 border   rounded-xl h-6 md:h-8 px-4 mr-2   text-xs">
                  {row}
                </div>
              );
            })}
      </div>
    );
  };

  return (
    // <Link href={`/technician/${productId}`}>
    <div className=" relative bg-white   font-Kanit  lg:mx-0   rounded-lg overflow-hidden shadow md:max-w-xs my-3">
      {/* <div
        onClick={() => setOpen(true)}
        className="text-red-700 text-3xl absolute top-1 left-2"
      >
        x
      </div> */}
      <DeleteModal
        choose="true"
        setOpen={setOpen}
        open={open}
        title="คุณต้องการจะลบใช่หรือไม่ ?"
        description="ถ้าหากคุณลบแล้วจะไม่สามารถนำข้อมูลกลับมาได้ต้องการจะลบจริงหรือไม่"
        choose1="ใช่"
        choose2="ยกเลิก"
        thumnail={img}
        onfunction={onClickDelete}
      />
      <img
        src={imgbg}
        className="w-full h-20 md:h-48 object-cover object-bottom"
      />
      <div className="flex justify-center -mt-8">
        <img
          src={img}
          className="w-16 h-16 md:w-32 md:h-32 object-cover rounded-full border-solid border-white border-2  md:-mt-10 object-top"
        />
      </div>
      <div className="h-full">
        <div className="text-center px-3 pb-4 pt-1 md:pt-2 ">
          <h3 className=" text-sm md:text-xl   font-bold ">{name}</h3>

          <p className="md:mt-2  text-textgray text-xs md:text-base flex justify-center items-center    font-light">
            <svg
              className="w-5 h-5 mr-2"
              fill="currentColor"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"
                clipRule="evenodd"
              />
            </svg>{" "}
            <div className=" line-clamp-1">{province}</div>
          </p>
          <p className="mt-1 md:mt-2  font-light text-sm text-gray-700  pt-2">
            <Type />
          </p>
        </div>
        <div className="flex justify-center pb-2 -mt-1 md:mt-0  md:pb-4 text-grey-dark">
          <CalStar avgRating={avgRating} />
        </div>
        <div className="text-center text-xs text-white absolute right-2 top-2  bg-glass px-2 py-1  flex rounded-md">
          <svg
            className="w-4 h-4 my-auto mr-2"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
            ></path>
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
            ></path>
          </svg>
          <div className="my-auto ">{count_view}</div>
        </div>
      </div>
      <div className="mt-10">
        <div
          className="p-2 text-center absolute bottom-0 bg-red-500 text-white w-full cursor-pointer "
          onClick={() => setOpen(true)}
        >
          ลบ
        </div>
      </div>
    </div>
    // </Link>
  );
};

export default ProductCard;
