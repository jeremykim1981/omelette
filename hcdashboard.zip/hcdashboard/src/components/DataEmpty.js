import React from "react";

function DataEmpty({ text }) {
  return (
    <div className=" flex flex-col justify-center items-center -mt-20 w-full">
      <img className="w-1/2 h-auto" src="../nocontent.jpg"></img>
      <div className=" mx-4 mb-2   text-lg   text-center  text-blue-500  ">
        {text ? text : "ไม่พบข้อมูล"}
      </div>
    </div>
  );
}

export default DataEmpty;
