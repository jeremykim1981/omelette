import React from "react";
import classNames from "classnames";

function ContainerContent({ children, ...props }) {
  let customClassName = props?.className;
  return (
    <div
      className={classNames(`relative md:pt-24 pb-8 pt-4 bg-gray-50 min-h-screen ${customClassName}`)}
    >
      {children}
    </div>
  );
}

export default ContainerContent;
