import React, { useContext, useEffect } from "react";
import { useHistory, withRouter } from "react-router-dom";
import classNames from "classnames";
import SearchBar from "../Search/SearchBar";
import { AppContext } from "../../context/AppContext";

// COMPONENTS

function Navbar() {
  const { user, setUser } = useContext(AppContext);
  const showSearch = true;

  const logOut = async () => {
    localStorage.removeItem("jwt");
    setUser("");
  };

  return (
    <>
      <nav
        className={classNames(
          "absolute  bg-linear top-0 left-0 w-full z-10 bg-transparent md:flex-row md:flex-nowrap md:justify-start flex items-center py-4 p-4",
          { "py-3": !showSearch }
        )}
      >
        <div className="w-full mx-autp items-center flex justify-between md:flex-nowrap flex-wrap px-3">
          {showSearch ? (
            <div className="flex flex-start w-full  ml-4">
              <SearchBar />
              <div className="m-auto text-white uppercase ">User : {user?.name}</div>
            </div>
          ) : (
            <div></div>
          )}
          <div
            className="cursor-pointer  text-yellow-400 hover:text-black font-medium  bg-white px-4 py-2 rounded-lg"
            onClick={() => logOut()}
          >
            Logout
          </div>
        </div>
      </nav>
    </>
  );
}

export default withRouter(Navbar);
