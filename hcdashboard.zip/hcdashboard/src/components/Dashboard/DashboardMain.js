import { faUserCheck } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useEffect, useState } from "react";
import {
  QUERY_COUNT_APPOINTMENT,
  QUERY_COUNT_FINISH,
  QUERY_COUNT_QUOTATION,
  QUERY_TECHNICIAN_COUNT,
} from "../../appllo/query";
import CardStats from "../Card/CardStats";
import ContainerContent from "../Container/ContainerContent";
import ApolloClient from "../../appllo/apolloClient";
import { sum_array } from "../../functions/functions";

const DashboardMain = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(async () => {
    await LoadData();
  }, []);

  const LoadData = async () => {
    try {
      setLoading(true);

      const { data } = await client.query({
        query: QUERY_TECHNICIAN_COUNT,
      });

      const { data: quotation } = await client.query({
        query: QUERY_COUNT_QUOTATION,
      });

      const { data: appointment } = await client.query({
        query: QUERY_COUNT_APPOINTMENT,
      });

      const { data: finish } = await client.query({
        query: QUERY_COUNT_FINISH,
      });

      const count_technician = data?.users?.length;

      const count_click = sum_array(
        data?.users?.map((click) => {
          return click?.count_click;
        })
      );

      const count_view = sum_array(
        data?.users?.map((view) => {
          return view?.count_view;
        })
      );

      const count_quotation = quotation?.quatations?.length;

      const count_appointment = appointment?.appointments?.length;

      const count_finish = finish?.finances?.length;

      setData({
        count_technician: count_technician,
        count_click: count_click,
        count_view: count_view,
        count_quotation: count_quotation,
        count_appointment: count_appointment,
        count_finish: count_finish,
      });
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  return (
    <ContainerContent>
      <>
        <div className="relative pb-8  mt-8">
          <div className="px-4 md:px-10 mx-auto w-full">
            <div>
              {loading ? (
                <div>Loading...</div>
              ) : (
                <div className="grid grid-cols-5 gap-2">
                  <div className="w-full">
                    <CardStats
                      statIcon={<FontAwesomeIcon icon={faUserCheck} />}
                      statSubtitle="ยอดการเข้าชมช่างทั้งหมด"
                      statTitle={data?.count_view}
                      statArrow="up"
                      statPercent=""
                      statPercentColor="text-emerald-500"
                      statDescripiron=""
                      statIconName="fas fa-tasks"
                      statIconColor=" bg-yellow-500"
                    />
                  </div>
                  <div className="w-full">
                    <CardStats
                      statIcon={<FontAwesomeIcon icon={faUserCheck} />}
                      statSubtitle="ยอดการจองช่างทั้งหมด"
                      statTitle={data?.count_click}
                      statArrow="up"
                      statPercent=""
                      statPercentColor="text-emerald-500"
                      statDescripiron=""
                      statIconName="fas fa-tasks"
                      statIconColor=" bg-yellow-500"
                    />
                  </div>
                  <div className="w-full">
                    <CardStats
                      statIcon={<FontAwesomeIcon icon={faUserCheck} />}
                      statSubtitle="ยอดช่างทั้งหมด"
                      statTitle={data?.count_technician}
                      statArrow="up"
                      statPercent=""
                      statPercentColor="text-emerald-500"
                      statDescripiron=""
                      statIconName="fas fa-tasks"
                      statIconColor=" bg-yellow-500"
                    />
                  </div>
                  <div className="w-full">
                    <CardStats
                      statIcon={<FontAwesomeIcon icon={faUserCheck} />}
                      statSubtitle="จำนวนครั้งเสนอราคา"
                      statTitle={data?.count_quotation}
                      statArrow="up"
                      statPercent=""
                      statPercentColor="text-emerald-500"
                      statDescripiron=""
                      statIconName="fas fa-tasks"
                      statIconColor=" bg-yellow-500"
                    />
                  </div>
                  <div className="w-full">
                    <CardStats
                      statIcon={<FontAwesomeIcon icon={faUserCheck} />}
                      statSubtitle="จำนวนครั้งนัดหมาย"
                      statTitle={data?.count_appointment}
                      statArrow="up"
                      statPercent=""
                      statPercentColor="text-emerald-500"
                      statDescripiron=""
                      statIconName="fas fa-tasks"
                      statIconColor=" bg-yellow-500"
                    />
                  </div>
                  <div className="w-full">
                    <CardStats
                      statIcon={<FontAwesomeIcon icon={faUserCheck} />}
                      statSubtitle="ยอดช่างที่ทำงานเสร็จทั้งหมด"
                      statTitle={data?.count_finish}
                      statArrow="up"
                      statPercent=""
                      statPercentColor="text-emerald-500"
                      statDescripiron=""
                      statIconName="fas fa-tasks"
                      statIconColor=" bg-yellow-500"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </>
    </ContainerContent>
  );
};
export default DashboardMain;
