import { useEffect, useMemo, useState } from "react";
import {
  QUERY_SEARCH_FINANCE,
  QUERY_SEARCH_FINANCE_BY_ID,
  QUERY_SEARCH_USER,
} from "../../appllo/query";
import ApolloClient from "../../appllo/apolloClient";
import { getPathUrl } from "../../utils/getPathUrl";
import Select from "react-select";
import { TechnicianModals } from "../Modals/TechnicianModals";
import QuatationChatModal from "../Modals/QuatationChatModal";

const yello200 = "#FDE68A";
const gray800 = "#374151";

const ImageAndName_technician = ({
  name,
  image,
  province,
  sub_types,
  role,
}) => {
  return (
    <div className="flex">
      <div className="flex">
        <div className="w-16 h-16 mr-4 p-1">
          <img
            className="w-full h-full object-cover rounded-md"
            src={image?.url ? getPathUrl(image?.url) : "/logo/logo.PNG"}
          />
        </div>
        <div className="grid grid-cols-1">
          <div className="font-semibold text-sm my-auto">{name}</div>
          <div className="font-semibold text-sm my-auto">
            {sub_types?.slice(0, 5)?.map((row) => {
              return row.name + " ";
            })}
          </div>
          <div className="font-semibold text-sm my-auto">{province}</div>
        </div>
      </div>
      <div className="ml-auto my-auto">{role}</div>
    </div>
  );
};

const SearchBar = () => {
  const { client } = ApolloClient();
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [openFinance, setOpenFinance] = useState(false);
  const [recievedRowFinance, setRecievedRowFinance] = useState("");
  const [recievedRow, setRecievedRow] = useState("");
  const [getOptions, setGetOptions] = useState("");

  useEffect(async () => {
    try {
      setLoading(true);
      const { data } = await client.query({
        query: QUERY_SEARCH_USER,
      });
      const { data: finances } = await client.query({
        query: QUERY_SEARCH_FINANCE,
      });
      const technicians = data?.users?.map((row) => {
        return {
          value: row?.id,
          label: row?.firstname + " " + row?.lastname,
          key: "User",
          renderLabel: (
            <ImageAndName_technician
              name={row?.firstname + " " + row?.lastname}
              image={row?.image_avatar}
              province={row?.province}
              sub_types={row?.sub_types}
              role={row?.role?.name}
            />
          ),
        };
      });
      const finances_map = finances?.quatations?.map((row) => {
        return {
          label: row?.number,
          value: row?.id,
          key: "Finances",
          renderLabel: row?.number,
        };
      });
      setGetOptions({
        technicians,
        finances_map,
      });
    } catch (error) {
    } finally {
      setLoading(false);
    }
  }, []);

  const options = [
    {
      label: "ช่าง",
      options: getOptions?.technicians,
    },
    {
      label: "หมายเลข",
      options: getOptions?.finances_map,
    },
  ];

  const customStyles = {
    control: (base) => ({
      ...base,
      border: 0,
      boxShadow: "none",
      backgroundColor: "#F3F4F6",
    }),
    menu: (provided) => ({
      ...provided,
      border: "none",
      boxShadow: "none",
    }),
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isFocused && yello200,
      color: state.isFocused && gray800,
    }),
  };

  const handelChangePage = async (selectValue) => {
    if (selectValue?.key === "User") {
      setRecievedRow(selectValue.value);
      setOpen(true);
    }
    if (selectValue?.key === "Finances") {
      try {
        const { data: finances } = await client.query({
          query: QUERY_SEARCH_FINANCE_BY_ID,
          variables: {
            id: selectValue?.value,
          },
        });
        await setRecievedRowFinance(finances?.quatation);
        setOpenFinance(true);
      } catch (error) {}
    }
  };

  return (
    <div className=" z-10  text-gray-500 w-2/3  bg-white border-4 border-gray-100    rounded-2xl  focus:ring-2   outline-none  ">
      <Select
        placeholder="Search : ชื่อช่าง หรือ หมายเลขใบเสนอราคา"
        // value={{
        //   value: "Search... ชื่อช่าง หรือ หมายเลขใบเสนอราคา",
        //   label: "Search... ชื่อช่าง หรือ หมายเลขใบเสนอราคา",
        // }}
        options={options}
        isLoading={loading}
        getOptionLabel={(option) => option.renderLabel}
        getOptionValue={(option) => option.label}
        onChange={handelChangePage}
        styles={customStyles}
      />
      {recievedRow && (
        <TechnicianModals
          setOpen={setOpen}
          open={open}
          technician_id={recievedRow}
        />
      )}
      {recievedRowFinance && (
        <QuatationChatModal
          setOpen={setOpenFinance}
          open={openFinance}
          recievedRow={recievedRowFinance}
        />
      )}
    </div>
  );
};
export default SearchBar;
