import ContainerContent from "../Container/ContainerContent";
import React, { useMemo, useState, useEffect } from "react";
import ApolloClient from "../../appllo/apolloClient";
import { QUERY_FINANCE_TECHNICIAN } from "../../appllo/query";
import { ImageModal } from "../Modals/ImageModal";
import { FormatDate } from "../../functions/functions";
import { Table } from "../Table";

const ServiceFinancesMain = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState([]);
  const [open, setOpen] = useState(false);
  const [recievedRow, setRecievedRow] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(async () => {
    try {
      setLoading(true);
      const { data } = await client.query({
        query: QUERY_FINANCE_TECHNICIAN,
      });

      setData(data?.finances);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  }, [open]);

  const columns = useMemo(
    () => [
      {
        Header: "ชื่อ",
        accessor: "technician_name",
      },
      {
        Header: "ธนาคาร",
        accessor: "technician_bank_name",
      },
      {
        Header: "เลขที่บัญชี",
        accessor: "technician_bank_number",
      },
      {
        Header: "หมายเลขนัดหมาย",
        accessor: "appointment_number",
      },
      {
        Header: "ยอดเงิน/บาท",
        accessor: "technician_amount_cash",
        Cell: ({ row }) => {
          const customer_amount_cash = row?.original?.customer_amount_cash;
          const cal_customer =
            customer_amount_cash - (customer_amount_cash * 3) / 100;
          const cash = row.original.technician_amount_cash
            ? row?.original?.technician_amount_cash
            : cal_customer.toFixed(2);
          return <div>{cash}</div>;
        },
      },
      {
        Header: "สถานะ",
        accessor: "technician_status_approve",
        Cell: ({ row }) => {
          const status = row?.original?.status;
          if (status === "d") {
            return <div className=" text-gray-600">รอการชำระเงิน</div>;
          } else if (status === "e") {
            return <div className=" text-green-500">ชำระเงินเสร็จสิ้น</div>;
          } else {
            return <div className=" text-red-600">Error</div>;
          }
        },
      },
      {
        Header: "วัน/เวลาที่อนุมัติจ่าย",
        accessor: "technician_pay_date",
        Cell: ({ row }) => {
          const getdate = row?.original?.technician_pay_date;
          return <div>{FormatDate(getdate)}</div>;
        },
      },
      {
        Header: "ชื่อผู้อนุมัติ",
        accessor: "technician_approver_name",
      },
      {
        Header: "",
        accessor: "button",
        Cell: ({ row }) => {
          const status = row?.original?.status;
          if (status === "e") {
            return (
              <div className="flex justify-center  items-center w-24  mx-auto rounded-3xl  bg-gray-400   text-white px-2 py-1 text-xs">
                ชำระเงินแล้ว
              </div>
            );
          } else {
            return (
              <div className="flex justify-center  items-center w-24  mx-auto rounded-3xl  bg-yellow-400  text-white px-2 py-1 text-xs">
                รอการชำระเงิน
              </div>
            );
          }
        },
      },
    ],
    []
  );

  return (
    <ContainerContent>
      <div className="mx-8 border border-graytext rounded-xl bg-white pt-10">
        <div className="mx-4 text-xl  font-medium">การเงินของผู้ให้บริการ</div>
        <Table
          columns={columns}
          data={data}
          setOpen={setOpen}
          setRecievedRow={setRecievedRow}
        />
        {recievedRow && (
          <ImageModal
            image={recievedRow}
            setOpen={setOpen}
            open={open}
            mode="technician"
          />
        )}
      </div>
    </ContainerContent>
  );
};
export default ServiceFinancesMain;
