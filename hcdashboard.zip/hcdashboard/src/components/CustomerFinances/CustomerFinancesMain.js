import ContainerContent from "../Container/ContainerContent";
import { Table } from "../Table";
import React, { useMemo, useState, useEffect } from "react";
import ApolloClient from "../../appllo/apolloClient";
import { QUERY_FINANCE_CUSTOMER } from "../../appllo/query";
import { ImageModal } from "../Modals/ImageModal";
import { FormatDate } from "../../functions/functions";

const CustomerFinancesMain = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState([]);
  const [open, setOpen] = useState(false);
  const [recievedRow, setRecievedRow] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(async () => {
    try {
      setLoading(true);
      const { data } = await client.query({
        query: QUERY_FINANCE_CUSTOMER,
      });

      setData(data?.finances);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  }, [open]);

  const columns = useMemo(
    () => [
      {
        Header: "ชื่อลูกค้า",
        accessor: "customer_name",
      },
      {
        Header: "ชื่อช่าง",
        accessor: "technician_name",
      },
      // {
      //   Header: "อีเมล",
      //   accessor: "email",
      //   Cell: ({ row }) => {
      //     return <div className="">{row.original.email}</div>;
      //   },
      // },
      {
        Header: "หมายเลขนัดหมาย",
        accessor: "appointment_number",
      },
      {
        Header: "ยอดเงิน/บาท",
        accessor: "customer_amount_cash",
      },
      {
        Header: "สถานะ",
        accessor: "customer_status_approve",
        Cell: ({ row }) => {
          const status = row?.original?.status;
          if (status === "a") {
            return <div className=" text-gray-600">รอการชำระเงิน</div>;
          } else {
            return <div className=" text-green-500">ชำระเงินเสร็จสิ้น</div>;
          }
        },
      },
      {
        Header: "วันเวลาที่อนุมัติจ่าย",
        accessor: "customer_pay_date",
        Cell: ({ row }) => {
          const getDate = row?.original?.customer_pay_date;
          return <div>{FormatDate(getDate)}</div>;
        },
      },
      {
        Header: "ชื่อผู้อนุมัติ",
        accessor: "approver",
        Cell: ({ row }) => {
          // const admin = row?.original?.user
          const token = row?.original?.token ? "Omise" : "";
          return <div>{token}</div>;
        },
      },
      {
        Header: "",
        accessor: "button",
        Cell: ({ row }) => {
          const status = row?.original?.status;
          if (status === "a") {
            return "";
          }
          if (status === "b") {
            return (
              <button className="  flex justify-center  items-center w-20  mx-auto rounded-3xl  bg-yellow-400  text-white px-2 py-1 text-xs">
                รออนุมัติ
              </button>
            );
          } else {
            return (
              <div className="  flex justify-center  items-center w-20  mx-auto rounded-3xl  bg-gray-400  text-white px-2 py-1 text-xs">
                อนุมัติแล้ว
              </div>
            );
          }
        },
      },
    ],
    []
  );

  return (
    <ContainerContent>
      <div className="mx-8 border border-graytext rounded-xl bg-white pt-10">
        <div className="mx-4 text-xl  font-medium">การเงินของลูกค้า</div>
        <Table
          columns={columns}
          data={data}
          setOpen={setOpen}
          setRecievedRow={setRecievedRow}
        />
        {recievedRow && (
          <ImageModal
            image={recievedRow}
            setOpen={setOpen}
            open={open}
            mode="customer"
          />
        )}
      </div>
    </ContainerContent>
  );
};
export default CustomerFinancesMain;
