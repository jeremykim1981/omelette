import { useTable } from "react-table";
import { check_even } from "../functions/functions";
import { Link } from "react-router-dom";

export const Table = ({ columns, data, setOpen, setRecievedRow }) => {
  const onClickRowOrigin = (row) => {
    setRecievedRow(row);

    setOpen(true);
  };

  const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } =
    useTable({
      columns,
      data,
    });

  // Render the UI for your table
  if (!data) return "";
  return (
    <table
      className=" mt-6 my-10 bg-white w-full text-sm   "
      {...getTableProps()}
    >
      <thead>
        {headerGroups.map((headerGroup) => (
          <tr
            className="bg-white border border-t-0 border-l-0 border-r-0  border-graytext  text-texthead h-16     "
            {...headerGroup.getHeaderGroupProps()}
          >
            {headerGroup.headers.map((column) => (
              <th
                className=" w-auto  text-left px-4  font-medium   "
                {...column.getHeaderProps()}
              >
                {column.render("Header")}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map((row, index) => {
          prepareRow(row);
          return (
            <tr
              onClick={() => onClickRowOrigin(row?.original)}
              className="bg-white text-gray-700 border border-t-0 border-l-0 border-r-0  border-graytext   hover:bg-blue-50 cursor-pointer  h-16   "
              // className={
              //   check_even(index) === "even" ? " bg-blue-50 mx-auto w-40  " : "  bg-white   "
              // }
              {...row.getRowProps()}
            >
              {row.cells.map((cell) => {
                return (
                  <td className="px-4 " {...cell.getCellProps()}>
                    {cell.render("Cell")}
                  </td>
                );
              })}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export const ReferralTable = ({ columns, data }) => {
  const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } =
    useTable({
      columns,
      data,
    });

  // Render the UI for your table
  if (!data) return "";
  return (
    <table
      className=" mt-6 my-10 bg-white w-full text-sm   "
      {...getTableProps()}
    >
      <thead>
        {headerGroups.map((headerGroup) => (
          <tr
            className="bg-white border border-t-0 border-l-0 border-r-0  border-graytext  text-texthead h-16     "
            {...headerGroup.getHeaderGroupProps()}
          >
            {headerGroup.headers.map((column) => (
              <th
                className=" w-auto  text-left px-4  font-medium   "
                {...column.getHeaderProps()}
              >
                {column.render("Header")}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map((row, index) => {
          prepareRow(row);
          return (
            <tr
              className="bg-white text-gray-700 border border-t-0 border-l-0 border-r-0  border-graytext   hover:bg-blue-50 cursor-pointer  h-16   "
              {...row.getRowProps()}
            >
              {row.cells.map((cell) => {
                return (
                  <td className="px-4" {...cell.getCellProps()}>
                    <Link to={`/referral/${row?.original.id}`}>
                      {cell.render("Cell")}
                    </Link>
                  </td>
                );
              })}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};
