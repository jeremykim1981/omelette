import ContainerContent from "../Container/ContainerContent";
import React, { useMemo, useState, useEffect } from "react";
import { Table } from "../Table";
import ApolloClient from "../../appllo/apolloClient";
import { QUERY_REGISTER } from "../../appllo/query";
import { RegisterModals } from "../Modals/RegisterModal";

const ApplicationServiceMain = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState([]);
  const [open, setOpen] = useState(false);
  const [recievedRow, setRecievedRow] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(async () => {
    try {
      setLoading(true);
      const { data } = await client.query({
        query: QUERY_REGISTER,
      });

      setData(data?.registers);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  }, [open]);

  const columns = useMemo(
    () => [
      {
        Header: "ชื่อ",
        accessor: "name",
      },
      {
        Header: "อีเมล",
        accessor: "email",
      },
      {
        Header: "เบอร์",
        accessor: "phone",
      },
      {
        Header: "จังหวัด",
        accessor: "province",
      },
      {
        Header: "ความถนัด",
        accessor: "tag",
      },
      // {
      //   Header: "แพกเกจ",
      //   accessor: "package",
      //   Cell: ({ row }) => {
      //     return <div className="">{row.original.package}</div>;
      //   },
      // },
      // {
      //   Header: "สถานะ",
      //   accessor: "status",
      //   Cell: ({ row }) => {
      //     return <div className=" text-green-500">{row.original.status}</div>;
      //   },
      // },
      {
        Header: "",
        accessor: "button",
        Cell: ({ row }) => {
          const status = row?.original?.status;
          if (status === "Waiting") {
            return (
              <button className="  flex justify-center  items-center w-20  mx-auto rounded-3xl  bg-yellow-400  text-white px-2 py-1 text-xs">
                รออนุมัติ
              </button>
            );
          } else if (status === "Accept") {
            return (
              <div className="  flex justify-center  items-center w-20  mx-auto rounded-3xl  bg-green-600  text-white px-2 py-1 text-xs">
                อนุมัติแล้ว
              </div>
            );
          } else if (status === "Unaccept") {
            return (
              <div className="  flex justify-center  items-center w-20  mx-auto rounded-3xl  bg-red-500  text-white px-2 py-1 text-xs">
                ไม่อนุมัติ
              </div>
            );
          } else {
            return (
              <div className="  flex justify-center  items-center w-20  mx-auto rounded-3xl  bg-red-500  text-white px-2 py-1 text-xs">
                Error
              </div>
            );
          }
        },
      },
    ],
    []
  );

  return (
    <ContainerContent>
      <div className="mx-8 border border-graytext rounded-xl bg-white pt-10">
        <div className="mx-4 text-xl  font-medium">
          คำขอสมัครเป็นผู้ให้บริการ
        </div>
        {loading ? (
          <div>Loading.....</div>
        ) : (
          <div>
            <Table
              columns={columns}
              data={data}
              setOpen={setOpen}
              setRecievedRow={setRecievedRow}
            />
            <RegisterModals
              setOpen={setOpen}
              open={open}
              recievedRow={recievedRow}
            />
          </div>
        )}
      </div>
    </ContainerContent>
  );
};
export default ApplicationServiceMain;
