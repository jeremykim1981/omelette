import ContainerContent from "../Container/ContainerContent";
import React, { useMemo, useState, useEffect } from "react";
import { ReferralTable, Table } from "../Table";
import { QUERY_REFERRAL, QUERY_USER_BY_ID } from "../../appllo/query";
import ApolloClient from "../../appllo/apolloClient";
import { FormatDate, sum_array } from "../../functions/functions";
import { ImageModal } from "../Modals/ImageModal";
import { faCoins } from "@fortawesome/free-solid-svg-icons";
import Loading from "../Loading/LoadingPage";

const ReferralFinance = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState([]);
  const [referral, setReferral] = useState("");
  const [recievedRow, setRecievedRow] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(async () => {
    let where = {
      referral: window?.location?.pathname?.split("/")[2],
      status: ["e", "f"],
    };
    try {
      setLoading(true);
      const { data } = await client.query({
        query: QUERY_REFERRAL,
        variables: {
          where: where,
        },
      });
      const { data: ref } = await client.query({
        query: QUERY_USER_BY_ID,
        variables: {
          id: window?.location?.pathname?.split("/")[2],
        },
      });
      setReferral(ref.user);
      setData(data?.finances);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  }, [open]);

  const total_money = data
    ?.filter((row) => {
      const status = row?.status;
      return status === "e";
    })
    ?.map((row) => {
      const customer_amount_cash = row?.customer_amount_cash;
      return customer_amount_cash;
    });

  const sum = (sum_array(total_money) / 100) * 1.25;

  const columns = useMemo(
    () => [
      {
        Header: "ชื่อ",
        accessor: "customer_name",
      },
      {
        Header: "หมายเลขนัดหมาย",
        accessor: "appointment_number",
      },
      {
        Header: "ยอดเงิน/บาท",
        accessor: "count",
        Cell: ({ row }) => {
          const count = (row?.original?.customer_amount_cash / 100) * 1.25;
          return <div>{count}</div>;
        },
      },
      {
        Header: "วัน-เวลาที่ชำระเงิน",
        accessor: "referral_pay_date",
        Cell: ({ row }) => {
          const getdate = row?.original?.referral_pay_date;
          return <div>{FormatDate(getdate)}</div>;
        },
      },
      {
        Header: "",
        accessor: "button",
        Cell: ({ row }) => {
          const status = row?.original?.status;
          if (status === "f") {
            return (
              <div className="flex justify-center  items-center w-24  mx-auto rounded-3xl  bg-gray-400   text-white px-2 py-1 text-xs">
                ชำระเงินแล้ว
              </div>
            );
          } else {
            return (
              <div className="flex justify-center  items-center w-24  mx-auto rounded-3xl  bg-yellow-400  text-white px-2 py-1 text-xs">
                รอการชำระเงิน
              </div>
            );
          }
        },
      },
    ],
    []
  );

  return (
    <ContainerContent>
      {loading ? (
        <div className="flex justify-center items-center mb-10 ">
          <Loading />
        </div>
      ) : (
        <div>
          <div className="mx-8 border border-graytext rounded-xl bg-white pt-10 ">
            <div className="mx-4 text-xl  font-medium">
              ข้อมูลบัญชีผู้มีบุคคลอ้างอิง
            </div>
            <div className="grid grid-cols-3 px-4 gap-4 pt-4 pb-10">
              <div>
                ชื่อ {referral?.firstname} {referral?.lastname}
              </div>
              <div>อีเมล {referral?.email || "ไม่ระบุ"}</div>
              <div>เบอร์โทรศัพท์ {referral?.phone_number || "ไม่ระบุ"}</div>
              <div>เลขที่บัญชี {referral?.bank_account || "ไม่ระบุ"}</div>
              <div>ชื่อบัญชี {referral?.bank_name_account || "ไม่ระบุ"}</div>
              <div>ชื่อธนาคาร {referral?.bank_name || "ไม่ระบุ"}</div>
            </div>
          </div>
          <div className="px-12 py-4 flex justify-end text-green-500  ">
            ยอดเงินรวมที่ยังไม่ได้ชำระ : {sum.toFixed(2)}
          </div>
          <div className="mx-8 border border-graytext rounded-xl bg-white pt-10">
            <div className="mx-4 text-xl  font-medium">บุคคลอ้างอิง</div>
            <Table
              columns={columns}
              data={data}
              setOpen={setOpen}
              setRecievedRow={setRecievedRow}
            />
            {recievedRow && (
              <ImageModal
                image={recievedRow}
                setOpen={setOpen}
                open={open}
                mode="referral"
              />
            )}
          </div>
        </div>
      )}
    </ContainerContent>
  );
};
export default ReferralFinance;
