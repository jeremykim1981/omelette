import ContainerContent from "../Container/ContainerContent";
import React, { useMemo, useState, useEffect } from "react";
import { ReferralTable } from "../Table";
import { QUERY_REFERRAL, QUERY_USER } from "../../appllo/query";
import ApolloClient from "../../appllo/apolloClient";
import { sum_array } from "../../functions/functions";
import Loading from "../Loading/LoadingPage";

const ReferralMain = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  const getTotal = async (id) => {
    const { data: ref } = await client.query({
      query: QUERY_REFERRAL,
      variables: {
        where: { referral: id, status: "e" },
      },
    });
    return (
      (sum_array(
        ref?.finances
          ?.filter((row) => {
            const status = row?.status;
            return status === "e";
          })
          ?.map((row) => {
            const customer_amount_cash = row?.customer_amount_cash;
            return customer_amount_cash;
          })
      ) /
        100) *
      1.25
    );
  };

  useEffect(async () => {
    try {
      setLoading(true);
      const { data } = await client.query({
        query: QUERY_USER,
      });
      const newData = await Promise.all(
        data?.users?.map(async (item) => {
          return { ...item, ref: await getTotal(item?.id) };
        })
      );

      // const users = [...data?.users];
      // users?.forEach(async (user, index) => {
      //   const { data: ref } = await client.query({
      //     query: QUERY_REFERRAL,
      //     variables: {
      //       where: { referral: user?.id, status: "d" },
      //     },
      //   });
      //   users[index] = await {
      //     ...users[index],
      //     ref:
      //       [
      //         sum_array(
      //           ref?.finances
      //             ?.filter((row) => {
      //               const status = row?.status;
      //               return status === "d";
      //             })
      //             ?.map((row) => {
      //               const customer_amount_cash = row?.customer_amount_cash;
      //               return customer_amount_cash;
      //             })
      //         ) / 100,
      //       ] * 1.5,
      //   };
      // });
      setData(newData);

      // setData(users);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  }, []);

  const columns = useMemo(
    () => [
      {
        Header: "ชื่อ",
        accessor: "name",
        Cell: ({ row }) => {
          const full_name =
            row?.original?.firstname + " " + row?.original?.lastname;
          return <div>{full_name}</div>;
        },
      },
      {
        Header: "อีเมล",
        accessor: "email",
      },
      {
        Header: "เบอร์",
        accessor: "phone_number",
      },
      {
        Header: "ยอดเงิน/บาท",
        accessor: "count",
        Cell: ({ row }) => {
          const total_money = row?.original?.ref;
          return <div>{total_money}</div>;
        },
      },
      {
        Header: "",
        accessor: "button",
        Cell: ({ row }) => {
          const total_money = row?.original?.ref;
          if (total_money > 0) {
            return (
              <div className="flex justify-center   items-center">
                <div className="  flex justify-center  items-start w-24  mx-auto rounded-3xl   text-red-500 px-2 py-1 text-sm">
                  <div>รอชำระ</div>
                  <img className="w-2 h-2 ml-2" src="../icon/dot.png" />
                </div>
                <svg
                  className="w-4 h-4  text-texthead mr-4"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
                </svg>
              </div>
            );
          } else return "";
        },
      },
    ],
    []
  );
  return (
    <ContainerContent>
      <div className="mx-8 border border-graytext rounded-xl bg-white pt-10">
        <div className="mx-4 text-xl  font-medium">บุคคลอ้างอิง</div>
        {loading ? (
          <div className="flex justify-center items-center mb-10 ">
            <Loading />
          </div>
        ) : (
          <ReferralTable columns={columns} data={data} />
        )}
      </div>
    </ContainerContent>
  );
};
export default ReferralMain;
