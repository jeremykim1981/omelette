import ContainerContent from "../Container/ContainerContent";
import React, { useMemo, useState, useEffect } from "react";
import { Table } from "../Table";
import ApolloClient from "../../appllo/apolloClient";
import { QUERY_TECHNICIAN } from "../../appllo/query";
import { TechnicianModals } from "../Modals/TechnicianModals";
import Loading from "../Loading/LoadingPage";

const TechnicianMain = () => {
  const { client } = ApolloClient();
  const [data, setData] = useState([]);
  const [open, setOpen] = useState(false);
  const [recievedRow, setRecievedRow] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(async () => {
    try {
      setLoading(true);
      const { data } = await client.query({
        query: QUERY_TECHNICIAN,
      });

      setData(data?.users);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  }, []);

  const columns = useMemo(
    () => [
      {
        Header: "ชื่อ",
        accessor: "name",
        Cell: (row) => {
          return (
            <div>
              {row?.row?.original?.firstname +
                " " +
                row?.row?.original?.lastname}
            </div>
          );
        },
      },
      // {
      //   Header: "อีเมล",
      //   accessor: "email",
      // },
      {
        Header: "เลขประจำตัวประชาชน",
        accessor: "identification_number",
      },
      // {
      //   Header: "หมวดหมู่",
      //   accessor: "sub_categories",
      // },
      // {
      //   Header: "แพ็กเกจ",
      //   accessor: "package",
      // },
      {
        Header: "หมายเลขโทรศัพท์",
        accessor: "phone_number",
      },
      {
        Header: "ยอดการเข้าชม",
        accessor: "count_view",
      },
      {
        Header: "ยอดการจอง",
        accessor: "count_click",
      },
      // {
      //   Header: "วันที่เหลือ",
      //   accessor: "exp",
      //   Cell: (row) => {
      //     return <div>x days</div>;
      //   },
      // },

      {
        Header: "",
        accessor: "button",
        Cell: ({ row }) => {
          return (
            <div>
              {row.original.status === "Public" ? (
                <div className=" flex justify-center items-center mr-4">
                  <div className="  flex justify-center  items-center w-24 mx-auto rounded-3xl  bg-green-400  text-white px-2 py-1 text-xs">
                    {row.original.button}
                    ออนไลน์
                  </div>
                  <div className="text-texthead">
                    <svg
                      className="w-6 h-6 "
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
                    </svg>
                  </div>
                </div>
              ) : (
                <div className=" flex justify-center items-center mr-4">
                  <div className="  flex justify-center  items-center w-24 mx-auto rounded-3xl  bg-yellow-400  text-white px-2 py-1 text-xs">
                    {row.original.button}
                    รอแก้ไข
                  </div>
                  <div className="text-texthead">
                    <svg
                      className="w-6 h-6 "
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
                    </svg>
                  </div>
                </div>
              )}
            </div>
          );
        },
      },
    ],
    []
  );
  return (
    <ContainerContent>
      {loading ? (
        <div className="flex justify-center items-center mb-10 ">
          <Loading />
        </div>
      ) : (
        <div>
          <div className="mx-8 border border-graytext rounded-xl bg-white pt-10">
            <div className="mx-4 text-xl  font-medium">ผู้ให้บริการ</div>{" "}
            <Table
              columns={columns}
              data={data}
              setOpen={setOpen}
              setRecievedRow={setRecievedRow}
            />
            <TechnicianModals
              setOpen={setOpen}
              open={open}
              technician_id={recievedRow?.id}
            />
          </div>
        </div>
      )}
    </ContainerContent>
  );
};
export default TechnicianMain;
