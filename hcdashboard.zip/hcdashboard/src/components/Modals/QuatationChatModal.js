import { Fragment, useEffect, useRef, useState } from "react";
import { Dialog, Transition } from "@headlessui/react";
import { getPathUrl } from "../../utils/getPathUrl";
import _ from "lodash";
import {
  formatDateEng,
  pust_seven_date,
  today,
} from "../../functions/functions";

export default function QuatationChatModal({ setOpen, open, recievedRow }) {
  const cancelButtonRef = useRef(null);
  if (!recievedRow) return <div></div>;
  const titleStyle = "text-gray-700 mr-2 font-bold";
  const textStyle = "text-gray-500";
  const boxLineStyle = "flex my-1";
  const { customer_name, technician_name } = recievedRow;
  ////////////////////////////////////////////////////////////////////////////////
  const result_all_cost = recievedRow?.Order?.reduce((prev, cur) => {
    const count = Number(cur?.count);
    const price = Number(cur?.price_per_unit);
    const result = count * price;
    return result + prev;
  }, 0);

  const discount = recievedRow?.discount;
  const price_before_tax = result_all_cost - [discount ? discount : 0];
  const tax = recievedRow?.tax;
  const customer_price =
    Number(result_all_cost) + Number(tax) - Number([discount ? discount : 0]);
  const cost = {
    result_all_cost: result_all_cost,
    discount: discount,
    price_before_tax: price_before_tax,
    tax: tax,
    customer_price: customer_price,
  };
  ////////////////////////////////////////////////////////////////////////////////

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog
        as="div"
        static
        className="fixed z-50 inset-0 overflow-y-auto"
        initialFocus={cancelButtonRef}
        open={open}
        onClose={setOpen}
      >
        <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300 "
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <Dialog.Overlay className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
          </Transition.Child>

          {/* This element is to trick the browser into centering the modal contents. */}
          <span
            className="hidden sm:inline-block sm:align-middle sm:h-screen"
            aria-hidden="true"
          >
            &#8203;
          </span>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            enterTo="opacity-100 translate-y-0 sm:scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 translate-y-0 sm:scale-100"
            leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
          >
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all ">
              <div className="w-a4 h-a4 p-4">
                <div className=" h-full relative font-Kanit">
                  <div className="p-8">
                    <div className="flex">
                      {recievedRow?.logo ? (
                        <div className="w-1/5">
                          <img
                            src={getPathUrl(recievedRow?.logo?.url)}
                            className="w-28 h-28 m-auto"
                          />
                        </div>
                      ) : (
                        ""
                      )}
                      {/* <div className="w-4/5"> */}
                      <div className={recievedRow?.logo ? "w-4/5" : "w-full"}>
                        <div className="">
                          บริษัท : {recievedRow?.companny_name || "-"}
                        </div>
                        <div className="">ชื่อช่าง : {technician_name}</div>
                        <div className="">
                          ที่อยู่ : {recievedRow?.technician_address}
                        </div>
                        <div className="">
                          โทรศัพท์ :{" "}
                          {recievedRow?.technician_phone_number || "-"}
                        </div>
                      </div>
                    </div>
                    <div className="text-center text-3xl">ใบเสนอราคา</div>
                    <div className="flex justify-between">
                      <div className={boxLineStyle}>
                        <div className={titleStyle}>ลูกค้า</div>
                        <div className={textStyle}>{customer_name}</div>
                      </div>
                      <div className={boxLineStyle}>
                        <div className={titleStyle}>เลขที่</div>
                        <div className={textStyle}>{recievedRow?.number}</div>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <div className={boxLineStyle}>
                        <div className={titleStyle}>ที่อยู่</div>
                        <div className={textStyle}>
                          {recievedRow?.customer_address || "-"}
                        </div>
                      </div>
                      <div className={boxLineStyle}>
                        <div className={titleStyle}>วันที่</div>
                        <div className={textStyle}>
                          {formatDateEng(recievedRow?.createdAt)}
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between">
                      <div className={boxLineStyle}>
                        <div className={titleStyle}>โทรศัพท์</div>
                        <div className={textStyle}>
                          {recievedRow?.customer_phone_number || "-"}
                        </div>
                      </div>
                      {/* <div className={boxLineStyle}>
                        <div className={titleStyle}>กำหนดยืนราคา</div>
                        <div className={textStyle}>
                          {pust_seven_date(recievedRow?.createdAt)}
                        </div>
                      </div> */}
                    </div>

                    <div className="flex justify-between">
                      <div className={boxLineStyle}>
                        <div className={titleStyle}>อีเมล์</div>
                        <div className={textStyle}>
                          {recievedRow?.customer_email}
                        </div>
                      </div>
                      <div className={boxLineStyle}>
                        <div className={titleStyle}>ระยะเวลาในการดำเนินงาน</div>
                        <div className={textStyle}>
                          {recievedRow?.duration || "1 วัน"}
                        </div>
                      </div>
                    </div>
                    <div className="text-center mt-4 mb-10">
                      ทางเรามีความยินดีขอเสนอราคาและแจ้งรายละเอียดให้ท่านทราบดังนี้
                    </div>
                    <table className="text-sm table-fixed border border-gray-600 w-full text-center">
                      <thead>
                        <tr>
                          <th className="w-1/12 border border-gray-600">
                            ลำดับ
                          </th>
                          <th className="w-4/12 border border-gray-600 ">
                            รายละเอียด
                          </th>
                          <th className="w-2/12 border border-gray-600 ">
                            จำนวน
                          </th>
                          <th className="w-2/12 border border-gray-600 ">
                            ราคาต่อหน่วย
                          </th>
                          <th className="w-3/12 border border-gray-600 ">
                            ราคารวม
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {recievedRow?.Order?.length > 0 &&
                          recievedRow?.Order?.map((product, index) => {
                            return (
                              <tr>
                                <td className="border border-gray-600 border-t-0 border-b-0 border-l-0">
                                  {index + 1}
                                </td>
                                <td className="text-left border border-gray-600 border-t-0 border-b-0 border-l-0">
                                  <div className="ml-4">{product?.name}</div>
                                  <div className="ml-4">
                                    ({product?.detail})
                                  </div>
                                </td>
                                <td className="border border-gray-600 border-t-0 border-b-0 border-l-0">
                                  {/* {product?.count + " " + product?.dot} */}
                                  <div className="w-full flex">
                                    <div className="text-center ml-6">
                                      {product?.count}
                                    </div>
                                    <div className="text-right ml-auto mx-2">
                                      {product?.unit}
                                    </div>
                                  </div>
                                </td>
                                <td className="border border-gray-600 border-t-0 border-b-0 border-l-0">
                                  {product?.price_per_unit}
                                </td>
                                <td className="border border-gray-600 border-t-0 border-b-0 border-l-0">
                                  {product?.count * product?.price_per_unit}
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                    <table className="text-sm w-full border border-gray-600 border-t-0 text-center">
                      <tbody>
                        <tr>
                          <td className="w-3/4 text-right border border-gray-600 border-t-0 border-b-0 border-l-0">
                            <div className="mr-2">รวมเงิน</div>
                          </td>
                          <td className="w-1/4 text-center">
                            {cost?.result_all_cost}
                          </td>
                        </tr>
                        <tr>
                          <td className="w-3/4 text-right border border-gray-600 border-t-0 border-b-0 border-l-0">
                            <div className="mr-2">ส่วนลด</div>
                          </td>
                          <td className="w-1/4 text-center">
                            {cost?.discount}
                          </td>
                        </tr>
                        <tr>
                          <td className="w-3/4 text-right border border-gray-600 border-t-0 border-b-0 border-l-0">
                            <div className="mr-2">ราคาก่อนภาษีมูลค่าเพิ่ม</div>
                          </td>
                          <td className="w-1/4 text-center">
                            {cost?.price_before_tax}
                          </td>
                        </tr>
                        <tr>
                          <td className="w-3/4 text-right border border-gray-600 border-t-0 border-b-0 border-l-0">
                            <div className="mr-2">ภาษีมูลค่าเพิ่ม 7%</div>
                          </td>
                          <td className="w-1/4 text-center">{cost?.tax}</td>
                        </tr>
                        <tr>
                          <td className="w-3/4 text-right border border-gray-600  border-b-0 border-l-0 bg-yellow">
                            <div className="mr-2">จำนวนเงินทั้งสิ้น</div>
                          </td>
                          <td className="w-1/4 text-center border border-gray-600 boerder-b-0 border-l-0 border-r-0 bg-yellow">
                            {cost?.customer_price}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <div className="mt-4 mb-2">หมายเหตุ</div>
                    {recievedRow?.note}
                    <div className="my-6" />
                    <div className="absolute bottom-12 flex justify-evenly w-11/12 ">
                      <div className="">
                        {/* <div className="rounded-lg border border-gray-600 w-72 h-28 mb-4" /> */}
                        <div className="text-center">
                          Authorized Signature / Date
                        </div>
                        <div className="text-center">{customer_name}</div>
                        <div className="text-center">(Customer)</div>
                      </div>
                      <div className="">
                        {/* <div className="rounded-lg border border-gray-600 w-72 h-28 mb-4" /> */}
                        <div className="text-center">
                          Authorized Signature / Date
                        </div>
                        <div className="text-center">{technician_name}</div>
                        <div className="text-center">(Technician)</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={() => setOpen(false)}
                  ref={cancelButtonRef}
                >
                  ยกเลิก
                </button>
              </div>
            </div>
          </Transition.Child>
        </div>
      </Dialog>
    </Transition.Root>
  );
}
