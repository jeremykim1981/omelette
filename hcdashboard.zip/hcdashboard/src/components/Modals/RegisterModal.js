import { Fragment, useEffect, useRef, useState } from "react";
import { Dialog, Transition } from "@headlessui/react";
import ApolloClient from "../../appllo/apolloClient";
import { QUERY_TECHNICIAN_BY_ID } from "../../appllo/query";
import { getPathUrl } from "../../utils/getPathUrl";
import ImageGallery from "react-image-gallery";
import { CREATE_TECNICIAN, UPDATE_STATUS } from "../../appllo/mutation";
import { check_length_name } from "../../functions/functions";

const buttonStyle =
  "  my-4 text-lg w-full mx-auto ustify-center rounded-md  shadow-sm px-4 py-2  font-medium  hover:bg-gray-50 focus:outline-none  text-white sm:mt-0 sm:ml-3 sm:text-sm";

export const RegisterModals = ({ setOpen, open, recievedRow }) => {
  const { client } = ApolloClient();
  const [loading, setLoading] = useState(false);
  const images = recievedRow?.profile_image?.map((image) => {
    const imgUrl = getPathUrl(image?.url);
    return { original: imgUrl, thumbnail: imgUrl };
  });

  const objectName = check_length_name(recievedRow?.name);
  const cancelButtonRef = useRef(null);

  // image_cover {
  //   provider
  //   url
  // }
  // profile_image {
  //   provider
  //   url
  // }
  // province
  // id_card {
  //   provider
  //   url
  // }

  const onClickAccept = async () => {
    try {
      setLoading(true);
      await client.mutate({
        mutation: CREATE_TECNICIAN,
        variables: {
          input: {
            data: {
              username: recievedRow?.username,
              email: recievedRow?.email,
              password: recievedRow?.password,
              role: "608181388b806b0455878e4f",
              firstname: objectName?.firstname,
              lastname: objectName?.lastname,
              identification_number: recievedRow?.citizen_number,
              phone_number: recievedRow?.phone,
              address: recievedRow?.address_detail,
              // subtype : recievedRow?.tag
              work_day: recievedRow?.work_day,
              work_time: recievedRow?.work_time,
              off_time: recievedRow?.off_time,
              description: recievedRow?.description,
            },
          },
        },
      });
      await client.mutate({
        mutation: UPDATE_STATUS,
        variables: {
          input: {
            where: {
              id: recievedRow?.id,
            },
            data: {
              status: "Accept",
            },
          },
        },
      });
    } catch (error) {
    } finally {
      setLoading(false);
      setOpen(false);
    }
  };
  const onClickUnaccept = async () => {
    try {
      setLoading(true);
      await client.mutate({
        mutation: UPDATE_STATUS,
        variables: {
          input: {
            where: {
              id: recievedRow?.id,
            },
            data: {
              status: "Unaccept",
            },
          },
        },
      });
    } catch (error) {
    } finally {
      setLoading(false);
      setOpen(false);
    }
  };

  return (
    <div>
      <Transition.Root show={open} as={Fragment}>
        <Dialog
          as="div"
          static
          className="fixed z-10 inset-0 "
          initialFocus={cancelButtonRef}
          open={open}
          onClose={setOpen}
        >
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <Dialog.Overlay className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
            </Transition.Child>
            <span
              className="hidden sm:inline-block sm:align-middle sm:h-screen"
              aria-hidden="true"
            >
              &#8203;
            </span>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <div className=" inline-block align-bottom  bg-white rounded-lg text-left   overflow-y-scroll  shadow-xl transform transition-all sm:my-8 sm:align-middle w-a4 h-a4 relative ">
                <div className="bg-white text-textgraydark  pt-5 pb-4 sm:p-6 sm:pb-4 rounded-lg ">
                  <div className=" flex justify-center items-center w-2/3 mx-auto">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <div>
                        <Dialog.Title
                          as="h3"
                          className="text-3xl leading-6 font-medium  text-textgraydark  flex flex-col justify-center items-center py-4"
                        >
                          โปรไฟล์ขอสมัครเป็นผู้ให้บริการ
                        </Dialog.Title>
                        <div className="mb-6 mt-6 ">
                          <div>
                            <div className="mb-2">
                              รูปถ่ายคู่บัตรประชำตัวประชาชน
                              <img
                                className="my-4"
                                src={getPathUrl(recievedRow?.id_card?.url)}
                                alt="id_card"
                              />
                            </div>
                            {/* <div className="h-52 w-auto">
                              รูปโปรไฟล์
                              {images?.length && (
                                <ImageGallery
                                  items={images}
                                  imagesautoPlay={false}
                                  showThumbnails={false}
                                  showFullscreenButton={false}
                                  showPlayButton={false}
                                  showNav={true}
                                  autoPlay={false}
                                />
                              )}
                            </div> */}
                            {/* <div>
                              cover image
                              <img
                                src={getPathUrl(recievedRow?.image_cover?.url)}
                                alt="id_card"
                              />
                            </div> */}
                            <div className="grid grid-cols-1 gap-2">
                              <div>ชื่อ : {recievedRow?.name}</div>
                              <div>เบอร์ : {recievedRow?.phone}</div>
                              <div>อีเมล : {recievedRow?.email}</div>
                              <div>
                                เลขประจำตัวประชาชน :
                                {recievedRow?.citizen_number}
                              </div>
                              <div>จังหวัด : {recievedRow?.province}</div>
                              <div>
                                รายละเอียดที่อยู่ :{recievedRow?.address_detail}
                              </div>
                              <div>ความถนัด : {recievedRow?.tag}</div>
                              <div>คำอธิบาย : {recievedRow?.description}</div>
                              <div>วันทำงาน : {recievedRow?.work_days}</div>
                              <div className="flex justify-between">
                                <div>
                                  เวลาเริ่มงาน : {recievedRow?.work_time}
                                </div>
                                <div>
                                  {" "}
                                  เวลาเลิกงาน : {recievedRow?.off_time}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className=" mt-0  w-2/3 mx-auto    ">
                  {recievedRow.status === "Waiting" ? (
                    <div>
                      <button
                        type="button"
                        className={`${buttonStyle}  bg-red-500`}
                        onClick={() => onClickUnaccept()}
                        ref={cancelButtonRef}
                      >
                        ไม่อนุมัติ
                      </button>
                      <button
                        type="button"
                        className={`${buttonStyle} bg-linear  `}
                        onClick={() => onClickAccept()}
                        ref={cancelButtonRef}
                      >
                        อนุมัติ
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      className={`${buttonStyle} bg-linear `}
                      onClick={() => setOpen(false)}
                      ref={cancelButtonRef}
                    >
                      กลับ
                    </button>
                  )}
                </div>
              </div>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>
    </div>
  );
};
