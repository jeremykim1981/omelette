import { Fragment, useEffect, useRef, useState, useCallback } from "react";
import { Dialog, Transition } from "@headlessui/react";
import { getPathUrl } from "../../utils/getPathUrl";
import {
  FormatDate,
  readFile,
  uploadFormData,
  ZeroPad,
} from "../../functions/functions";
import CelesFloatingInputState from "../Field/CelesFloatingInputState";
import "../../App.css";
import ApolloClient from "../../appllo/apolloClient";
import { UPDATE_FINANCE } from "../../appllo/mutation";
import Loading from "../Loading/LoadingPage";
import numeral from "numeral";

const image_size =
  " text-sm w-96 h-96  border border-dashed  rounded mx-auto my-4 text-textgraydark  flex flex-col  justify-center items-center  object-contain ";

export const ImageModal = ({ setOpen, open, image, mode }) => {
  const { client } = ApolloClient();
  const [file, setFile] = useState("");
  const [imageSrc, setImageSrc] = useState("");
  const [form, setForm] = useState("");
  const [loading, setLoading] = useState(false);

  const setField = useCallback(
    (field) => (e) => {
      const value = e && e.target ? e.target.value : e;
      setForm((currentForm) => ({
        ...currentForm,
        [field]: value,
      }));
    },
    [setForm]
  );

  useEffect(() => {
    setForm({
      day: ZeroPad(new Date().getDate(), 2),
      month: ZeroPad(new Date().getMonth() + 1, 2),
      year: new Date().getFullYear(),
      time: ZeroPad(new Date().getHours(), 2),
      min: ZeroPad(new Date().getMinutes(), 2),
    });
  }, [open]);

  const image_customer = image?.customer_money_transfer_slip?.url;
  const image_technician = image?.technician_money_transfer_slip?.url;
  const image_referral = image?.referral_money_transfer_slip?.url;

  const ShowSilp = ({ slip }) => {
    return (
      <div>
        <img className={image_size} src={getPathUrl(slip)} />
      </div>
    );
  };

  const handleUploadChange = async ({ target: { files } }) => {
    const file = await files[0];
    let imageDataUrl = readFile(file);
    setFile(file);
    setImageSrc(imageDataUrl);
  };

  const onSubmit = async (file) => {
    try {
      setLoading(true);
      const technician_pay_date = `${form.year}|${form.month}|${form.day}|${form?.time}|${form?.min}`;
      await client.mutate({
        mutation: UPDATE_FINANCE,
        variables: {
          input: {
            where: {
              id: image?.id,
            },
            data: {
              technician_amount_cash: form?.technician_amount_cash,
              technician_pay_date: technician_pay_date,
              status: "e",
              technician_approver_name: localStorage.getItem("name"),
            },
          },
        },
      });
      await uploadFormData(
        file,
        "finance",
        image?.id,
        "technician_money_transfer_slip"
      );
      setOpen(false);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const onSubmitReferral = async (file) => {
    try {
      setLoading(true);
      const referral_pay_date = `${form.year}|${form.month}|${form.day}|${form?.time}|${form?.min}`;
      await client.mutate({
        mutation: UPDATE_FINANCE,
        variables: {
          input: {
            where: {
              id: image?.id,
            },
            data: {
              referral_amount_cash: form?.referral_amount_cash,
              referral_pay_date: referral_pay_date,
              status: "f",
            },
          },
        },
      });
      await uploadFormData(
        file,
        "finance",
        image?.id,
        "referral_money_transfer_slip"
      );
      setOpen(false);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const onClickAccept = async () => {
    try {
      setLoading(true);
      await client.mutate({
        mutation: UPDATE_FINANCE,
        variables: {
          input: {
            where: {
              id: image?.id,
            },
            data: {
              status: "c",
              customer_approver_name: localStorage.getItem("name"),
            },
          },
        },
      });
      setOpen(false);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const Field = ({ name }) => {
    return (
      <div className="p-4 mx-auto">
        <label for="button-file">
          {file ? (
            <img className={image_size} src={imageSrc} alt="" />
          ) : (
            <p className={image_size}>
              <svg
                className="w-6 h-6 mb-2  text-textgraydark"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"
                  clipRule="evenodd"
                />
              </svg>
              อัปโหลดรูป
            </p>
          )}
        </label>
        <CelesFloatingInputState
          label={"ยอดเงิน / บาท"}
          name={name}
          setField={setField}
          value={form?.[name]}
          isUseForm
        />
        <div className="flex p-1  ">
          <CelesFloatingInputState
            label={"วัน"}
            name="day"
            setField={setField}
            value={form?.day}
            isUseForm
          />
          <CelesFloatingInputState
            label={"เดือน"}
            name="month"
            setField={setField}
            value={form?.month}
            isUseForm
          />
          <CelesFloatingInputState
            label={"ปี"}
            name="year"
            setField={setField}
            value={form?.year}
            isUseForm
          />
        </div>
        <div className="flex">
          <CelesFloatingInputState
            label={"เวลา"}
            name="time"
            setField={setField}
            value={form?.time}
            isUseForm
          />
          <CelesFloatingInputState
            label={"นาที"}
            name="min"
            setField={setField}
            value={form?.min}
            isUseForm
          />
        </div>
      </div>
    );
  };

  const cancelButtonRef = useRef(null);
  return (
    <div>
      <Transition.Root show={open} as={Fragment}>
        <Dialog
          as="div"
          static
          className="fixed z-10 inset-0 overflow-y-auto"
          initialFocus={cancelButtonRef}
          open={open}
          onClose={setOpen}
        >
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0 ">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <Dialog.Overlay className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity " />
            </Transition.Child>

            {/* This element is to trick the browser into centering the modal contents. */}
            <span
              className="hidden sm:inline-block sm:align-middle sm:h-screen"
              aria-hidden="true"
            >
              &#8203;
            </span>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              {/* <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full"> */}
              <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle w-3/5 h-full">
                {mode === "customer" ? (
                  <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 ">
                    <div className="flex justify-center  items-center mb-6">
                      {image_customer ? (
                        <div className="text-textgraydark">
                          <ShowSilp slip={image_customer} />
                          <div className=" flex justify-between items-center">
                            <div>ยอดเงิน</div>
                            <div>
                              {numeral(image?.customer_amount_cash).format(
                                "0,0.00"
                              )}{" "}
                              บาท
                            </div>
                          </div>
                          <div className=" flex justify-between items-center">
                            <div> วันที่</div>
                            <div>{FormatDate(image?.customer_pay_date)}</div>
                          </div>
                          {image.status === "b" ? (
                            <div
                              onClick={() => onClickAccept()}
                              className=" w-full  cursor-pointer mx-auto flex  justify-center items-center text-white bg-yellow-400 px-4 py-2 rounded mt-4 text-sm"
                            >
                              ยืนยัน
                            </div>
                          ) : (
                            <div className=" w-full cursor-pointer mx-auto flex  justify-center items-center text-white bg-gray-400 px-4 py-2 rounded mt-4 text-sm">
                              อนุมัติแล้ว
                            </div>
                          )}
                        </div>
                      ) : (
                        ""
                      )}
                      {image?.token ? (
                        <div className="text-textgraydark">
                          <div className=" grid grid-cols-1 items-center">
                            <div>Omise Token : {image?.token}</div>
                            <div>
                              ยอดเงิน :{" "}
                              {numeral(image?.customer_amount_cash).format(
                                "0,0.00"
                              )}{" "}
                              บาท
                            </div>
                          </div>
                          <div className=" flex justify-between items-center">
                            <div>
                              วันที่ : {FormatDate(image?.customer_pay_date)}
                            </div>
                          </div>
                        </div>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                ) : (
                  [
                    mode === "technician" ? (
                      <div className="bg-white  px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                        <div className="flex justify-center  items-center">
                          {image_technician ? (
                            <div className=" text-textgraydark">
                              <ShowSilp slip={image_technician} />
                              <div className="flex justify-between items-center">
                                <div>ยอดเงิน</div>
                                <div>
                                  {numeral(
                                    image?.technician_amount_cash
                                  ).format("0,0.00")}{" "}
                                  บาท
                                </div>
                              </div>
                              <div className="flex justify-between items-center">
                                <div>วันที่ </div>
                                <div className="text-right">
                                  {FormatDate(image?.technician_pay_date)}
                                </div>
                              </div>
                            </div>
                          ) : (
                            <Field name="technician_amount_cash" />
                          )}
                        </div>
                      </div>
                    ) : (
                      <div>
                        {image_referral ? (
                          <div className="w-2/3 flex flex-col mx-auto text-textgraydark mb-6">
                            <ShowSilp slip={image_referral} />
                            <div className="flex justify-between items-center">
                              <div>ยอดเงิน</div>
                              <div>
                                {numeral(image?.referral_amount_cash).format(
                                  "0,0.00"
                                )}{" "}
                                บาท
                              </div>
                            </div>
                            <div className="flex justify-between items-center">
                              <div>วันที่ เวลา</div>
                              <div className="text-right">
                                {FormatDate(image?.referral_pay_date)}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <Field name="referral_amount_cash" />
                        )}
                      </div>
                    ),
                  ]
                )}

                {loading ? (
                  <div className="flex justify-center items-center mb-10 ">
                    <Loading />
                  </div>
                ) : (
                  <div className="flex bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    {mode === "technician"
                      ? [
                          !image_technician && (
                            <button
                              type="button"
                              className="mt-3 w-full inline-flex justify-center bg-green-500 rounded-md border border-green-500 shadow-sm px-4 py-2 hover:text-green-500   text-white text-base font-medium  hover:bg-gray-50 focus:outline-none  sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                              onClick={() => onSubmit(file)}
                              ref={cancelButtonRef}
                            >
                              ยืนยัน
                            </button>
                          ),
                        ]
                      : [
                          !image_referral && mode !== "customer" && (
                            <button
                              type="button"
                              className="mt-3 w-full inline-flex justify-center bg-green-500 rounded-md border border-green-500 shadow-sm px-4 py-2 hover:text-green-500   text-white text-base font-medium  hover:bg-gray-50 focus:outline-none  sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                              onClick={() => onSubmitReferral(file)}
                              ref={cancelButtonRef}
                            >
                              ยืนยัน
                            </button>
                          ),
                        ]}

                    <button
                      type="button"
                      className="mt-3 w-full inline-flex justify-center rounded-md border bg-red-500 border-red-500  hover:text-red-500 shadow-sm px-4 py-2 text-white text-base font-medium  hover:bg-gray-50 focus:outline-none  sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={() => setOpen(false)}
                      ref={cancelButtonRef}
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>
      <input
        accept="image/jpeg,image/gif,image/png"
        className="hidden"
        id="button-file"
        type="file"
        onChange={handleUploadChange}
      />
    </div>
  );
};
