import { Fragment, useEffect, useRef, useState } from "react";
import { Dialog, Transition } from "@headlessui/react";
import ApolloClient from "../../appllo/apolloClient";
import { QUERY_TECHNICIAN_BY_ID } from "../../appllo/query";
import Loading from "../Loading/LoadingPage";
import { getPathUrl } from "../../utils/getPathUrl";
import ReactImageGallery from "react-image-gallery";
import "react-image-gallery/styles/css/image-gallery.css";

const border_of_content_style =
  "border border-yellowtext rounded-md shadow-md p-4 my-4 brake-all";
const tilte_style = "text-2xl text-center mb-4";
const titleTableStyle = "text-black text-xl my-10";

export const TechnicianModals = ({ setOpen, open, technician_id }) => {
  const { client } = ApolloClient();
  const [loadingTechnician, setLoadingTechnician] = useState(true);
  const [profile, setProfile] = useState("");
  const role_technician = profile?.role?.name === "Technician";

  useEffect(async () => {
    if (!technician_id) return;
    try {
      setLoadingTechnician(true);
      const { data } = await client.query({
        query: QUERY_TECHNICIAN_BY_ID,
        variables: {
          id: technician_id,
        },
      });
      setProfile(data?.user);
    } catch (error) {
    } finally {
      setLoadingTechnician(false);
    }
  }, [technician_id]);

  const TextWithData = ({ title, data }) => {
    return (
      <div className="grid grid-cols-2">
        <div>{title}</div>
        <div> {data}</div>
      </div>
    );
  };

  const tags = profile?.sub_types?.map((type, index) => {
    return type?.name + " ";
  });

  const images = profile?.image_show?.map((image, index) => {
    const imgUrl = getPathUrl(image?.url);
    return { original: imgUrl, thumbnail: imgUrl };
  });

  const CheckTrue = () => {
    return (
      <svg
        className="w-8 h-8 text-green-500 mx-1"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
        ></path>
      </svg>
    );
  };
  const CheckFalse = () => {
    return (
      <svg
        className="w-8 h-8 text-red-500 mx-1"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
        ></path>
      </svg>
    );
  };

  const cancelButtonRef = useRef(null);

  return (
    <div>
      <Transition.Root show={open} as={Fragment}>
        <Dialog
          as="div"
          static
          className="fixed z-10 inset-0 overflow-y-auto"
          initialFocus={cancelButtonRef}
          open={open}
          onClose={setOpen}
        >
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <Dialog.Overlay className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
            </Transition.Child>

            {/* This element is to trick the browser into centering the modal contents. */}
            <span
              className="hidden sm:inline-block sm:align-middle sm:h-screen"
              aria-hidden="true"
            >
              &#8203;
            </span>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              {/* <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full"> */}
              <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all overflow-y-scroll w-9/12">
                <div className={role_technician ? " h-a4 p-4" : "h-80 p-4"}>
                  {profile && (
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                      {loadingTechnician ? (
                        <div className="flex justify-center items-center mb-10">
                          <Loading />
                        </div>
                      ) : (
                        <div>
                          {role_technician && (
                            <div>
                              <div className={border_of_content_style}>
                                <div className=" w-full mx-auto ">
                                  {images?.length && (
                                    <ReactImageGallery
                                      thumbnailPosition={"right"}
                                      items={images}
                                      imagesautoPlay={true}
                                      showThumbnails={true}
                                      showFullscreenButton={false}
                                      showPlayButton={false}
                                      showNav={false}
                                      autoPlay={false}
                                    />
                                  )}
                                </div>
                                <div className={border_of_content_style}>
                                  <div className=" my-4 grid gird-cols-1 md:grid-cols-2 lg:grid-cols-4">
                                    <div className="flex mx-2">
                                      ข้อมูล
                                      {profile?.identification_number &&
                                      profile?.phone_number &&
                                      profile?.province &&
                                      profile?.address ? (
                                        <CheckTrue />
                                      ) : (
                                        <CheckFalse />
                                      )}
                                    </div>
                                    <div className="flex mx-2">
                                      หมวดหมู่งาน{" "}
                                      {profile?.work_day &&
                                      profile?.work_time &&
                                      // profile?.off_time &&
                                      profile?.description &&
                                      profile?.sub_types?.length > 0 ? (
                                        <CheckTrue />
                                      ) : (
                                        <CheckFalse />
                                      )}
                                    </div>
                                    <div className="flex mx-2">
                                      การเงิน{" "}
                                      {profile?.bank_account &&
                                      profile?.bank_branch &&
                                      profile?.bank_name &&
                                      profile?.bank_name_account &&
                                      profile?.bank_type ? (
                                        <CheckTrue />
                                      ) : (
                                        <CheckFalse />
                                      )}
                                    </div>
                                    <div className="flex mx-2">
                                      รูปภาพจัดแสดง{" "}
                                      {profile?.image_show?.length > 0 ? (
                                        <CheckTrue />
                                      ) : (
                                        <CheckFalse />
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}

                          <div className="mx-auto grid grid-cols-1 lg:grid-cols-2 gap-4">
                            <div className={border_of_content_style}>
                              <div className={tilte_style}>ข้อมูล</div>
                              <TextWithData
                                title="เลขประจำตัวประชาชน"
                                data={profile?.identification_number}
                              />
                              <TextWithData
                                title="เบอร์โทรศัพร์มือถือ"
                                data={profile?.phone_number}
                              />
                              <TextWithData
                                title="จังหวัด"
                                data={profile?.province}
                              />
                              <TextWithData
                                title="ที่อยู่"
                                data={profile?.address}
                              />
                            </div>
                            {role_technician && (
                              <div className={border_of_content_style}>
                                <div>
                                  <div className={tilte_style}>หมวดหมู่งาน</div>
                                  <TextWithData title="หมวด" data={tags} />
                                </div>
                                <TextWithData
                                  title="วันทำงาน"
                                  data={profile?.work_day}
                                />
                                <TextWithData
                                  title="เวลางาน"
                                  data={
                                    [profile?.work_time]
                                    // + "-" + [profile?.off_time]
                                  }
                                />
                                <TextWithData
                                  title="คำอธิบาย"
                                  data={profile?.description}
                                />
                              </div>
                            )}

                            <div className={border_of_content_style}>
                              <div className={tilte_style}>การเงิน</div>
                              <TextWithData
                                title="เลขที่บัญชี"
                                data={profile?.bank_account}
                              />
                              <TextWithData
                                title="สาขาธนาคาร"
                                data={profile?.bank_branch}
                              />
                              <TextWithData
                                title="ธนาคาร"
                                data={profile?.bank_name}
                              />
                              <TextWithData
                                title="ชื่อบัญชี"
                                data={profile?.bank_name_account}
                              />
                              <TextWithData
                                title="ประเภทธนาคาร"
                                data={profile?.bank_type}
                              />
                            </div>
                            {role_technician && (
                              <div className={border_of_content_style}>
                                <div className={tilte_style}>ข้อมูลร้าน</div>
                                <div className="text-center">
                                  Logo ร้าน / บริษัท
                                </div>
                                <img
                                  className="w-28 h-28 mx-auto"
                                  src={getPathUrl(profile?.company_logo?.url)}
                                  alt=""
                                />
                                <TextWithData
                                  title="ชือร้าน / บริษัท"
                                  data={profile?.company_name}
                                />
                                <TextWithData
                                  title="เบอร์โทรร้าน / บริษัท"
                                  data={profile?.company_phone}
                                />
                                <TextWithData
                                  title="เลขประจำตัวผู้เสียภาษี"
                                  data={profile?.tax_number}
                                />

                                <TextWithData
                                  title="จังหวัด"
                                  data={profile?.company_province}
                                />
                                <TextWithData
                                  title="รายละเอียดที่อยู่"
                                  data={profile?.company_address}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  <div className=" bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button
                      type="button"
                      className="mt-3 text-lg w-full inline-flex justify-center rounded-md  shadow-sm px-4 py-2  bg-linear font-medium  hover:bg-gray-50 focus:outline-none  text-white sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={() => setOpen(false)}
                      ref={cancelButtonRef}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>
    </div>
  );
};
