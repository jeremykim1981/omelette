import React, { memo, useState } from "react";

const CelesFloatingInputState = memo(
  ({
    disable = false,
    type = "text",
    label,
    value,
    setValue,
    backgroundColor = "#ffffff80",
    className = "text-gray-800 opacity-95",
    name,
    setField,
    isUseForm,
  }) => {
    const handleChange = (e) => {
      if (isUseForm) {
        setField(name)(e.target.value);
      } else {
        setValue(e.target.value);
      }
    };
    return (
      <form className="input-container" autoComplete={false}>
        <input
          disabled={disable}
          type={type}
          className={className}
          style={{ backgroundColor: backgroundColor }}
          value={value}
          onChange={handleChange}
        />
        <label className={value != undefined && value != "" && "filled"}>
          {label}
        </label>
      </form>
    );
  }
);

export default CelesFloatingInputState;
