export default function Loading() {
  return (
    <button type="button" className="inline-flex items-center px-4 py-2 border border-transparent text-base leading-6 font-medium rounded-md text-white bg-yellow-400 hover:bg-yellow-400 focus:border-yellow-400 active:bg-yellow-400 transition ease-in-out duration-150 cursor-not-allowed" disabled>
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx={12} cy={12} r={10} stroke="currentColor" strokeWidth={4} />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
    </svg>
    Loading
  </button>

    // <div className="flex items-center justify-center h-screen">
    //   <style
    //     dangerouslySetInnerHTML={{
    //       __html:
    //         "\n\n.loader-dots div {\n    animation-timing-function: cubic-bezier(0, 1, 1, 0);\n}\n.loader-dots div:nth-child(1) {\n    left: 8px;\n    animation: loader-dots1 0.6s infinite;\n}\n.loader-dots div:nth-child(2) {\n    left: 8px;\n    animation: loader-dots2 0.6s infinite;\n}\n.loader-dots div:nth-child(3) {\n    left: 32px;\n    animation: loader-dots2 0.6s infinite;\n}\n.loader-dots div:nth-child(4) {\n    left: 56px;\n    animation: loader-dots3 0.6s infinite;\n}\n@keyframes loader-dots1 {\n    0% {\n        transform: scale(0);\n    }\n    100% {\n        transform: scale(1);\n    }\n}\n@keyframes loader-dots3 {\n    0% {\n        transform: scale(1);\n    }\n    100% {\n        transform: scale(0);\n    }\n}\n@keyframes loader-dots2 {\n    0% {\n        transform: translate(0, 0);\n    }\n    100% {\n        transform: translate(24px, 0);\n    }\n}\n",
    //     }}
    //   />
    //   <div className="z-50" style={{ background: "rgba(255, 255, 255, 0.0)" }}>
    //     <div className="bg-white border py-2 px-5 rounded-lg flex items-center flex-col">
    //       <div className="loader-dots block relative w-20 h-5 mt-2">
    //         <div className="absolute top-0 mt-1 w-3 h-3 rounded-full bg-blue-500" />
    //         <div className="absolute top-0 mt-1 w-3 h-3 rounded-full bg-blue-500" />
    //         <div className="absolute top-0 mt-1 w-3 h-3 rounded-full bg-blue-500" />
    //         <div className="absolute top-0 mt-1 w-3 h-3 rounded-full bg-blue-500" />
    //       </div>
    //       <div className="text-gray-700 text-xs font-light mt-2 text-center">
    //         Please wait...
    //       </div>
    //     </div>
    //   </div>
    // </div>
  );
}
