import axios from "axios";
import moment from "moment";

export const check_even = (number) => {
  if (number % 2 == 0) {
    return "even";
  } else {
    return "old";
  }
};

export const readFile = (file) => {
  if (!file) return;
  if (file) {
    const src = URL.createObjectURL(file);
    return src;
  }
};

export const uploadFile = async (formData) => {
  return await axios({
    method: "POST",
    url: "https://admin.celestialproperty-api.xyz/upload",
    data: formData,
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
};

export const uploadFormData = async (files, ref, taskId, field) => {
  const formDataUpload = new FormData();
  formDataUpload.append("refId", taskId);
  formDataUpload.append("ref", ref);
  formDataUpload.append("field", field);
  formDataUpload.append("files", files);
  await uploadFile(formDataUpload);
};

export const ZeroPad = (num, numZeros) => {
  var n = Math.abs(num);
  var zeros = Math.max(0, numZeros - Math.floor(n).toString().length);
  var zeroString = Math.pow(10, zeros).toString().substr(1);
  if (num < 0) {
    zeroString = "-" + zeroString;
  }

  return zeroString + n;
};

export const FormatDate = (date) => {
  if (!date) return;
  if (date?.length === 20) {
    const x = date;
    const objectDate = new Date(x);
    const y = x.split("T")[0];
    const format = y.split("-");
    const hours = objectDate.getHours();
    const mins = objectDate.getMinutes();
    const formated =
      format[2] +
      "-" +
      format[1] +
      "-" +
      format[0] +
      " " +
      ZeroPad(hours, 2) +
      ":" +
      ZeroPad(mins, 2) +
      " น.";
    return formated;
  } else {
    const y = date.split("|");
    const format =
      y[2] + "-" + y[1] + "-" + y[0] + " " + y[3] + ":" + y[4] + " น.";
    return format;
  }
};

export const formatDateEng = (date) => {
  const formated = moment(date).subtract(10, "days").calendar();
  const swap = formated.split("/");
  return swap[1] + "/" + swap[0] + "/" + swap[2];
};

export const sum_array = (value) => {
  if (!value) return;
  var total = 0;
  for (var i = 0; i < value.length; i++) {
    if (isNaN(value[i])) {
      continue;
    }
    total += Number(value[i]);
  }
  return total;
};

export const check_length_name = (input) => {
  if (!input) return;
  const cal_length = input.split(" ");
  if (cal_length?.length === 2) {
    return { firstname: cal_length[0], lastname: cal_length[1] };
  }

  if (cal_length?.length === 3) {
    return { firstname: cal_length[1], lastname: cal_length[2] };
  }
};

export const pust_seven_date = (date) => {
  const date_pust_already = moment(date)
    .subtract(10, "days")
    .add(7, "days")
    .calendar();
  // const split_date = date_pust_already.split("/");
  // const result = split_date[1] + "/" + split_date[0] + "/" + split_date[2];
  // return result;
};

export const today = (date) => {
  const day = new Date().getDate();
  const month = new Date().getMonth() + 1;
  const year = new Date().getFullYear();
  return ZeroPad(day, 2) + "/" + ZeroPad(month, 2) + "/" + year;
};

export const calculaterStar = (ratings, amount_of_comment) => {
  if (ratings && amount_of_comment) {
    const allscore = ratings?.map((row) => row?.score);

    function sum(input) {
      if (toString.call(input) !== "[object Array]") return false;

      let total = 0;
      for (let i = 0; i < input.length; i++) {
        if (isNaN(input[i])) {
          continue;
        }
        total += Number(input[i]);
      }
      return total;
    }

    const result = sum(allscore) / amount_of_comment;

    return result?.toFixed(1);
  } else {
    return;
  }
};
