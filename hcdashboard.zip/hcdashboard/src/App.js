import React, { useContext, useEffect, useState } from "react";
import { ApolloProvider } from "@apollo/client";
import ApolloClient from "./appllo/apolloClient";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useLocation,
} from "react-router-dom";
import NavBar from "./components/Layout/Navbar";
import Sidebar from "./components/Layout/Sidebar";
import ProtectedRoute from "./components/Route/ProtectedRoute";
import Loading from "./components/Loading/LoadingPage";
import DashboardMain from "./components/Dashboard/DashboardMain";
import ServiceFinancesMain from "./components/ServiceFinances/serviceFinancesMain";
import CustomerFinancesMain from "./components/CustomerFinances/CustomerFinancesMain";
import ReferralMain from "./components/Referral/referralMain";
import PackageRequestMain from "./components/PackageRequest/packageRequestMain";
import ApplicationServiceMain from "./components/ApplicationService/applicationServiceMain";
import TechnicianMain from "./components/Technician/technicianMain";
import ReferralFinance from "./components/Referral/ReferralFinance";
import admin from "./components/admin";
import { AppContext } from "./context/AppContext";
import RecommendMain from "./components/Recommend/RecommendMain";

function App() {
  const { client } = ApolloClient();
  const [showSidebar, setShowSidebar] = useState(true);
  const { user } = useContext(AppContext);

  return (
    <div className="  ">
      <ApolloProvider client={client}>
        <Router>
          {user &&
            user.token !== undefined &&
            user.token !== null &&
            user.token && (
              <React.Fragment>
                <Sidebar
                  setShowSidebar={setShowSidebar}
                  showSidebar={showSidebar}
                />
                <div
                  className={
                    "hidden md:block relative " +
                    (showSidebar ? "md:ml-64" : "")
                  }
                >
                  <NavBar />
                </div>
              </React.Fragment>
            )}
          <Switch>
            <Route path="/admin" component={admin} />
            <div className={"relative " + (showSidebar ? "md:ml-64" : "")}>
              <ProtectedRoute exact path="/" component={DashboardMain} />
              <ProtectedRoute
                path="/serviceFinances"
                component={ServiceFinancesMain}
              />
              <ProtectedRoute
                path="/customerFinances"
                component={CustomerFinancesMain}
              />
              <ProtectedRoute exact path="/referral" component={ReferralMain} />
              <ProtectedRoute
                exact
                path="/referral/:referral_id"
                component={ReferralFinance}
              />
              {/* <ProtectedRoute
                // exact
                path="/packageRequest"
                component={PackageRequestMain}
              /> */}
              <ProtectedRoute
                path="/applicationService"
                component={ApplicationServiceMain}
              />
              <ProtectedRoute path="/technician" component={TechnicianMain} />
              <ProtectedRoute path="/recommend" component={RecommendMain} />
            </div>
          </Switch>
        </Router>
      </ApolloProvider>
    </div>
  );
}

export default App;
