module.exports = {
  purge: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      colors: {
        graytext: "#DFE0EB",
        texthead: "#9FA2B4",
        textpopup: "#77899A",
        textgraydark: "#676767",
      },
      width: {
        a4: "635px",
      },
      height: {
        a4: "898px",
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
};
